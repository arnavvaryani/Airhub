from flask import Flask, request, render_template, jsonify, redirect, url_for, session, flash, g
from werkzeug.security import check_password_hash, generate_password_hash
import functools
import pyodbc

app = Flask(__name__)
app.config.update(SECRET_KEY='dev')

conn = pyodbc.connect(
    'DRIVER={SQL Server};'
    'SERVER=DESKTOP-1ULGF16;'
    'DATABASE=AirHub;'
    'Trusted_Connection=yes;'
)
cursor = conn.cursor()

def view(table_name):
    cursor.execute("select * from {}".format(table_name))
    result = cursor.fetchall()
    return result

def get_airports():
    cursor.execute("SELECT * FROM Airport")
    return cursor.fetchall()

def get_airport_by_id(airport_id):
    cursor.execute("SELECT * FROM Airport WHERE AirportID = ?", (airport_id,))
    return cursor.fetchone()

def update_airport_in_db(airport_id, name, country, state, city, capacity):
    cursor.execute("UPDATE Airport SET [Name] = ?, Country = ?, [State] = ?, City = ?, Capacity = ? WHERE AirportID = ?", (name, country, state, city, capacity, airport_id))
    conn.commit()

def update_passenger_in_db(passenger_id, user_id, ticket_id, name, email, passport_number):
    cursor.execute("UPDATE Passenger SET UserID = ?, TicketID = ?, [Name] = ?, Email = ?, PassportNumber = ? WHERE PassengerID = ?",
                   (user_id, ticket_id, name, email, passport_number, passenger_id))
    conn.commit()

@app.route("/", methods=['GET', 'POST'])
def home():
    if request.method == 'GET':
        return render_template('home.html')

@app.before_request
def load_logged_in_user():
    uname = session.get('uname')
    if uname is None:
        g.uname = None
    else:
        g.uname = uname

def login_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if g.uname is None:
            return redirect(url_for('login'))
        return view(**kwargs)
    return wrapped_view

@app.route("/register", methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        # Handle registration logic here
        pass
    return render_template('register.html')

@app.route("/login", methods=['GET', 'POST'])
def login():
    error = None
    if request.args.get('user_reg'):
        flash('User successfully created!')
    if request.method == 'POST':
        username = str(request.form['input_uname'])
        password = str(request.form['input_passwd'])
        # Check for admin credentials
        if username == "admin" and password == "admin":
            session.clear()
            session['uname'] = username
            return redirect(url_for('crud_operations'))
        cursor.execute("SELECT * FROM UserAccount WHERE Name = '{}'"
                       .format(username))
        user = cursor.fetchone()
        if user is None:
            error = "Incorrect Username!"
        elif not check_password_hash(user[4], password):
            error = "Incorrect Password!"
        if error is None:
            session.clear()
            session['uname'] = user[0]
            return redirect(url_for('crud_operations'))
        flash(error)
    return render_template('login.html')

@app.route("/bookticket", methods=['GET', 'POST'])
@login_required
def bookticket():
    if request.method == 'GET':
        flights = view('Flight')
        return render_template('bookticket.html', flights=flights)
    else:
        flight_id = request.form['flight_id']
        return redirect(url_for('payment', flight=flight_id))

@app.route("/payment", methods=['GET', 'POST'])
@login_required
def payment():
    if request.method == 'GET' and not request.args.get('flight'):
        return redirect(url_for('bookticket'))
    elif request.args['flight']:
        flight_id = request.args['flight']
        # Your payment logic here
        return render_template('payment.html')

@app.route("/print", methods=['GET', 'POST'])
@login_required
def print_ticket():
    if request.method == 'GET':
        # Your print logic here
        return render_template('print.html')

# Example: Redirect to CRUD landing page after creating an airport
@app.route("/create_airport", methods=['GET', 'POST'])
def create_airport():
    if request.method == 'POST':
        airport_id = request.form['airport_id']
        name = request.form['name']
        country = request.form['country']
        state = request.form['state']
        city = request.form['city']
        capacity = request.form['capacity']

        # Insert into the Airport table
        cursor.execute("INSERT INTO Airport (AirportID, [Name], Country, [State], City, Capacity) VALUES (?, ?, ?, ?, ?, ?)", (airport_id, name, country, state, city, capacity))
        conn.commit()

    return render_template('create_airport.html')


@app.route("/crud_operations")
def crud_operations():
    return render_template('crud_operations.html')

@app.route("/read_airport")
def read_airport():
    airports = get_airports()
    return render_template('read_airport.html', airports=airports)

@app.route('/select_airport', methods=['GET', 'POST'])
def select_airport():
    # Fetch the list of airports from the database
    airports = get_airports()
    return render_template('select_airport.html', airports=airports)

@app.route('/show_update_form', methods=['POST'])
def show_update_form():
    airport_id = request.form['airport_id']
    airport = get_airport_by_id(airport_id)
    return render_template('update_airport.html', airport=airport)



@app.route('/update_airport', methods=['POST'])
def update_airport():
    airport_id = request.form['airport_id']
    name = request.form['name']
    country = request.form['country']
    state = request.form['state']
    city = request.form['city']
    capacity = request.form['capacity']

    # Update the airport in the database
    cursor.execute("UPDATE Airport SET [Name] = ?, Country = ?, [State] = ?, City = ?, Capacity = ? WHERE AirportID = ?", (name, country, state, city, capacity, airport_id))
    conn.commit()
    flash('Airport updated successfully!')
    return redirect(url_for('crud_operations'))

@app.route('/delete_airport', methods=['POST'])
def delete_airport():
    airport_id = request.form['airport_id']

    # Delete the airport from the database
    cursor.execute("DELETE FROM Airport WHERE AirportID = ?", (airport_id,))
    conn.commit()
    flash('Airport deleted successfully!')
    return redirect(url_for('crud_operations'))


@app.route('/delete_airport_value', methods=['GET', 'POST'])
def delete_airport_value():
    # Fetch the list of airports from the database
    cursor.execute("SELECT * FROM Airport")
    airports = cursor.fetchall()

    if request.method == 'POST':
        # Get the selected airport ID from the form
        airport_id = request.form['airport_id']
        
        # Delete the selected airport from the database
        cursor.execute("DELETE FROM Airport WHERE AirportID = ?", (airport_id,))
        conn.commit()

        # Redirect to the CRUD operations page with a success message
        flash('Airport deleted successfully!')
        return redirect(url_for('crud_operations'))

    return render_template('delete_airport_value.html', airports=airports)

# Existing code...

from flask import flash

@app.route("/create_passenger", methods=['GET', 'POST'])
def create_passenger():
    if request.method == 'POST':
        passenger_id = request.form['passenger_id']
        user_id = request.form.get('user_id', None)  # Optional field, default to None if not provided
        
        name = request.form['name']
        email = request.form['email']
        passport_number = request.form['passport_number']
        ticket_id = request.form.get('ticket_id', None)  # Optional field

        try:
            # Insert into the Passenger table
            cursor.execute("INSERT INTO Passenger (PassengerID, UserID, TicketID, [Name], Email, PassportNumber) VALUES (?, ?, ?, ?, ?, ?)",
                           (passenger_id, user_id or None, ticket_id or None, name, email, passport_number))
            
            conn.commit()
            flash('Passenger created successfully!')
            
            return redirect(url_for('crud_operations'))
        except pyodbc.IntegrityError as e:
            flash('An error occurred: ' + str(e))
            return render_template('create_passenger.html'), 400

    return render_template('create_passenger.html')



@app.route("/read_passenger")
def read_passenger():
    cursor.execute("SELECT * FROM Passenger")
    passengers = cursor.fetchall()
    return render_template('read_passenger.html', passengers=passengers)

@app.route('/select_passenger', methods=['GET', 'POST'])
def select_passenger():
    passengers = view('Passenger')
    return render_template('select_passenger.html', passengers=passengers)


@app.route('/show_update_passenger_form', methods=['POST'])
def show_update_passenger_form():
    passenger_id = request.form['passenger_id']
    
    passenger = get_passenger_by_id(passenger_id)
    return render_template('update_passenger.html', passenger=passenger)

def get_passenger_by_id(passenger_id):
    cursor.execute("SELECT * FROM Passenger WHERE PassengerID = ?", (passenger_id,))
    return cursor.fetchone()
@app.route('/update_passenger', methods=['POST'])
def update_passenger():
    passenger_id = request.form['passenger_id']
    user_id = request.form['user_id']
    ticket_id = request.form['ticket_id']
    name = request.form['name']
    email = request.form['email']
    passport_number = request.form['passport_number']

    try:
        # Update the passenger in the database
        cursor.execute("UPDATE Passenger SET UserID = ?, TicketID = ?, [Name] = ?, Email = ?, PassportNumber = ? WHERE PassengerID = ?",
                       (user_id, ticket_id, name, email, passport_number, passenger_id))
        conn.commit()
        flash('Passenger updated successfully!')
    except pyodbc.IntegrityError as e:
        flash('An error occurred: ' + str(e))
        conn.rollback()

    return redirect(url_for('crud_operations'))

@app.route('/delete_passenger', methods=['POST'])
def delete_passenger():
    passenger_id = request.form['passenger_id']

    # Delete the airport from the database
    cursor.execute("DELETE FROM passenger WHERE passengerID = ?", (passenger_id,))
    conn.commit()
    flash('passenger deleted successfully!')
    return redirect(url_for('crud_operations'))

@app.route('/delete_passenger_value', methods=['GET','POST'])
def delete_passenger_value():
    cursor.execute("SELECT * FROM passenger")
    passengers = cursor.fetchall()

    if request.method == 'POST':
        passenger_id = request.form['passenger_id']
        # Delete the passenger from the database
        cursor.execute("DELETE FROM Passenger WHERE PassengerID = ?", (passenger_id,))
        conn.commit()
        flash('Passenger deleted successfully!')
        return redirect(url_for('crud_operations'))
    return render_template('delete_passenger_value.html', passengers=passengers)


if __name__ == "__main__":
    app.run(debug=True)
